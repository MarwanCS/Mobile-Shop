package mobileshop;

import eu.hansolo.enzo.notification.Notification;
import java.util.Date;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class AddClass {

    TextField nametxt = new TextField();
    ComboBox typeCombo = new ComboBox();
    TextField valuetxt = new TextField();
    TextField numberOfThingtxt = new TextField();

    public void display() {
        //************************************* panakan
        Stage window = new Stage();
        BorderPane mainHbox = new BorderPane();

        BorderPane leftPn = new BorderPane();
        leftPn.setPrefSize(200, 500);
        leftPn.setStyle("-fx-background-color: #00A8F3");

        VBox rightBox = new VBox();
        rightBox.setSpacing(25);
        rightBox.setPrefSize(170, 500);
        rightBox.setPadding(new Insets(0, 0, 0, 0));

        mainHbox.setLeft(leftPn);
        mainHbox.setCenter(rightBox);

        //***************************************  componentakan
        nametxt.setPromptText(" name of thing");
        nametxt.setMaxWidth(200);

        typeCombo.getItems().addAll("Mobile", "parchay computer", "exsystwarat");
        typeCombo.setPrefWidth(200);
        typeCombo.setValue("Type");
        

        valuetxt.setPromptText("Price");
        valuetxt.setMaxWidth(200);

        numberOfThingtxt.setPromptText(" number of thing");
        numberOfThingtxt.setMaxWidth(200);

        Button saveBtn = new Button("Save");
        saveBtn.setStyle("-fx-background-color: #00A8F3");
        saveBtn.setPrefWidth(100);

        ImageView addimg = new ImageView(new Image("file:add.png"));
        addimg.setFitHeight(180);
        addimg.setFitWidth(180);

        ImageView backImg = new ImageView(new Image("file:back.png"));
        backImg.setFitHeight(30);
        backImg.setFitWidth(30);
        Button backBtn = new Button("", backImg);
        backBtn.setStyle("-fx-background-color: #00A8F3");
        backBtn.setPrefSize(50, 10);

        leftPn.setTop(backBtn);
        leftPn.setCenter(addimg);

        rightBox.getChildren().addAll(nametxt, numberOfThingtxt, typeCombo, valuetxt, saveBtn);
        rightBox.setAlignment(Pos.CENTER);

        //************************************** mouse entered and exited
        setStyleEnteredAndExited(backBtn);
        setStyleEnteredAndExited(saveBtn);

        //*************************************
        //*Actionakan
        backBtn.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                Home obj = new Home();
                window.close();
                obj.display();
            }
        });

        //actiony save krdn
        saveBtn.setOnAction((e) -> {

            saveMethod();
        });

        //kotayyactiony save krdn
        //
        Scene scene = new Scene(mainHbox, 700, 500);

        window.setTitle("Add Part");
        window.setScene(scene);
        window.show();
       
    }

    public void setStyleEnteredAndExited(Button btn) {
        btn.setOnMouseEntered(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                btn.setStyle("-fx-background-color : #1288ff");
            }
        });
        btn.setOnMouseExited(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                btn.setStyle("-fx-background-color: #00A8F3");
            }
        });
    }

    public void saveMethod() {
        try {
            String name_str = nametxt.getText();
            int numberOfThing_str = Integer.parseInt(numberOfThingtxt.getText());
            double price = Double.parseDouble(valuetxt.getText());
            String date_str = new Date() + "";
            String typeOfThing_str = typeCombo.getValue() + "";
            if (name_str.equals("") || typeOfThing_str.equals("Type")) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("please input all info");
                alert.show();
            }else{
                
                  Notification.Notifier.INSTANCE.notifySuccess("Successfully", "mawad added successfully");  
                  Koga ob=new Koga();
                  ob.addMawad(name_str, typeOfThing_str, numberOfThing_str, price, date_str);
            }

        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Please dont write charecter in number textfield");
            alert.show();
        } catch (Throwable e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("" + e);
            alert.show();
        }
    }
}
