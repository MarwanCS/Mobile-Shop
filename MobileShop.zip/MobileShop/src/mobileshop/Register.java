package mobileshop;

import eu.hansolo.enzo.notification.Notification;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Register {

    public void display() {
        //************************************* panakan
        Stage window = new Stage();

        BorderPane mainHbox = new BorderPane();
        mainHbox.setStyle("-fx-background-color: #ffffff");  //rangy spy dadayn ba borderpany saraky

        BorderPane leftPn = new BorderPane();
        leftPn.setPrefSize(180, 350);
        leftPn.setStyle("-fx-background-color: #00A8F3");

        VBox rightBox = new VBox();
        rightBox.setStyle("-fx-background-color: #ffffff");
        rightBox.setSpacing(25);
        rightBox.setPrefSize(170, 500);
        rightBox.setPadding(new Insets(0, 0, 0, 0));

        mainHbox.setCenter(rightBox);
        mainHbox.setLeft(leftPn);
        //***************************************  componentakan
        TextField userNameTxt = new TextField();
        userNameTxt.setPromptText("Username");
        userNameTxt.setMaxWidth(200);

        TextField paswordTxt = new TextField();
        paswordTxt.setMaxWidth(200);
        paswordTxt.setPromptText("Password");

        ComboBox ruleCombo = new ComboBox();
        ruleCombo.getItems().addAll("Employee", "Admin");
        ruleCombo.setPrefWidth(200);  //dyary krdny pany comboboxaka
        ruleCombo.setValue("Rule");

        Button registerBtn = new Button("Register");
        registerBtn.setStyle("-fx-background-color: #00A8F3");
        registerBtn.setPrefWidth(100);

        ImageView addImg = new ImageView(new Image("file:register.png"));
        addImg.setFitHeight(90);
        addImg.setFitWidth(120);
        leftPn.setCenter(addImg);

        rightBox.getChildren().addAll(userNameTxt, paswordTxt, ruleCombo, registerBtn);
        rightBox.setAlignment(Pos.CENTER);

        ImageView backImg = new ImageView(new Image("file:back.png"));
        backImg.setFitHeight(30);
        backImg.setFitWidth(30);
        Button backBtn = new Button("", backImg);
        backBtn.setStyle("-fx-background-color: #00A8F3");
        backBtn.setPrefSize(50, 10);
        leftPn.setTop(backBtn);
        //************************************** mouse entered and exited
        AddClass ob = new AddClass();
        ob.setStyleEnteredAndExited(registerBtn);
        ob.setStyleEnteredAndExited(backBtn);

        //*************************************
        //*Actionakan
        backBtn.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                Home obj = new Home();
                window.close();
                obj.display();
            }
        });
        registerBtn.setOnAction((e) -> {
            String rule_str = ruleCombo.getValue() + "";
            if (userNameTxt.getText().equals("") || paswordTxt.getText().equals("") || rule_str.equals("Rule")) {
                Notification.Notifier.INSTANCE.notifyError("Error", "Please Write all info");
            } else {
                createAccount(userNameTxt.getText(), paswordTxt.getText(), ruleCombo.getValue() + "");
                userNameTxt.setText("");
                paswordTxt.setText("");
                ruleCombo.setValue("Rule");

            }
        });

        //
        Scene scene = new Scene(mainHbox, 500, 350);

        window.setTitle("Register");
        window.setScene(scene);
        window.show();
    }

    public void createAccount(String username_str, String password_str, String rule_str) {

        try {
            String temp = username_str + password_str;
            for (int i = 0; i < temp.length(); i++) {
                if (temp.charAt(i) == '/') {
                    throw new IOException();
                }

            }

            String content = new String(Files.readAllBytes(Paths.get("accounts.txt")));
            FileWriter writer = new FileWriter("accounts.txt");
            writer.write(content);
            if(!content.equals(""))
            writer.write("//");
            writer.write(username_str + "/" + password_str + "/" + rule_str);
            writer.close();
            Notification.Notifier.INSTANCE.notifySuccess("Success", "The Account Create Successfully");
        } catch (IOException e) {
            System.out.println(e);
        } catch (IllegalAccessError e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erro");
            alert.setHeaderText("Please dont use ( / ) in username or password");
            alert.show();
        }

    }
}
