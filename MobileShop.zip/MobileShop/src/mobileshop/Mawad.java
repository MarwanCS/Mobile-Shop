
package mobileshop;

public class Mawad {
    
    String name;
    int numOfthing;
    String type;
    double price;
    String date;

    public Mawad(String name, int numOfthing, String type, double price, String date) {
        this.name = name;
        this.numOfthing = numOfthing;
        this.type = type;
        this.price = price;
        this.date = date;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumOfthing() {
        return numOfthing;
    }

    public void setNumOfthing(int numOfthing) {
        this.numOfthing = numOfthing;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
    
}
