package mobileshop;
import javafx.application.Application;

import javafx.stage.Stage;

public class MobileShop extends Application {

    @Override
    public void start(Stage primaryStage) {

        Login ob = new Login();
        ob.display();
    }

    public static void main(String[] args) {
        launch(args);
    }

}
