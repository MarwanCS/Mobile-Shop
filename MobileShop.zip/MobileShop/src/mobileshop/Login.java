package mobileshop;

import eu.hansolo.enzo.notification.Notification;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

public class Login {

    public void display() {
        //************************************* panakan
        Stage window = new Stage();

        BorderPane mainHbox = new BorderPane();

        BorderPane leftPn = new BorderPane();
        leftPn.setPrefSize(180, 350);
        leftPn.setStyle("-fx-background-color: #00A8F3");

        VBox rightBox = new VBox();
        rightBox.setStyle("-fx-background-color: #ffffff");
        rightBox.setSpacing(25);
        rightBox.setPrefSize(320, 500);
        rightBox.setPadding(new Insets(0, 0, 0, 0));

        mainHbox.setCenter(rightBox);   //vboxaka daxaynanawarasty borderpanaka
        mainHbox.setLeft(leftPn);   //pana shynaka daxayna lay chap

        //***************************************  componentakan
        TextField userNameTxt = new TextField();
        userNameTxt.setPromptText("Username");

        PasswordField paswordTxt = new PasswordField();
        paswordTxt.setPromptText("Password");

        Button loginBtn = new Button("Login");
        loginBtn.setStyle("-fx-background-color: #00A8F3");
        loginBtn.setPrefWidth(100);

        userNameTxt.setMaxWidth(200);  //dyary krdny pany username textfield
        paswordTxt.setMaxWidth(200);    //dyary krdny pany password textfield

        ImageView qflImg = new ImageView(new Image("file:qfl.png"));
        qflImg.setFitHeight(130);
        qflImg.setFitWidth(120);

        leftPn.setCenter(qflImg);  //rasmy welcome axayna  nawarasty basha shynaka 

        rightBox.getChildren().addAll(userNameTxt, paswordTxt, loginBtn);

        rightBox.setAlignment(Pos.CENTER);   //bo away shtakany sar vboxaka bcheta center

        //************************************** mouse entered and exited
        AddClass ob = new AddClass();
        ob.setStyleEnteredAndExited(loginBtn);

        //*************************************
        loginBtn.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                String regapedan = loginMethod(paswordTxt.getText(), userNameTxt.getText());
                if (!regapedan.equals("")) {
                    Home obj = new Home();
                    window.close();
                    Home.rule_str = regapedan;
                    System.out.println(Home.rule_str);
                    obj.display();
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Username or password wrong");
                    alert.show();
                }
            }
        });

        Scene scene = new Scene(mainHbox, 500, 350);

        window.setTitle("Login");
        window.setScene(scene);
        window.show();
    }

    public String loginMethod(String password_str, String username_str) {
        try {
            //****************************************************************************** Programa qwrsaka
            String content = new String(Files.readAllBytes(Paths.get("accounts.txt")));
            int count = 1;
            for (int i = 0; i < content.length(); i++) {
                if (content.charAt(i) == '/' && content.charAt(i + 1) == '/') {
                    count++;
                }
            }
            String accounts[][] = new String[count][3];
            int row = 0;
            int column = 0;
            String temp = "";
            for (int i = 0; i < content.length(); i++) {
                if (content.charAt(i) != '/') {
                    temp = temp + content.charAt(i);
                }
                if (content.charAt(i) == '/' && content.charAt(i + 1) != '/') {

                    accounts[row][column] = temp;
                    temp = "";
                    column++;
                    System.out.println(column + "" + content.charAt(i) + i);
                }
                if (content.charAt(i) == '/' && content.charAt(i + 1) == '/') {
                    System.out.println(row + "" + column);
                    accounts[row][column] = temp;
                    row++;
                    i++;
                    column = 0;
                    temp = "";
                }
            }
            accounts[row][column] = temp;

            //************************************************************ *********************************programma qwrsaka
            for (int i = 0; i < accounts.length; i++) {

                if (accounts[i][0].equals(username_str) && accounts[i][1].equals(password_str)) {
                    Home.username_str = username_str;

                    return accounts[i][2];
                }

            }
        } catch (IOException ex) {
            System.out.println(ex);
        }
        return "";
    }
}
