package mobileshop;

import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Scene;

import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class Home {

    static String username_str;
    static String rule_str;

    public void display() {

        Stage window = new Stage();
        BorderPane mainHbox = new BorderPane();

        HBox line = new HBox();

        // line.setStyle("-fx-background-color: #00b8f0");
        VBox general = new VBox();
        general.setSpacing(50);
        general.setAlignment(Pos.CENTER);
        line.setAlignment(Pos.CENTER);
        line.setSpacing(50);
        Image backgroundImage = new Image("file:background.png");
        ImageView background = new ImageView(backgroundImage);
        //*** Menu Bar
        MenuBar bar = new MenuBar();
        bar.setStyle("-fx-background-color: #00A8F3");
        mainHbox.setStyle("-fx-background-color: #fff");
        Menu File = new Menu("File");
        MenuItem ExitItem = new MenuItem("Exit");
        MenuItem logoutItem = new MenuItem("Logout");
        File.getItems().addAll(logoutItem, ExitItem);
        bar.getMenus().addAll(File);

        //***
        //about image
        Image aboutImg = new Image("file:about1.png");
        Circle aboutCircle = new Circle(200, 200, 60);
        aboutCircle.setFill(new ImagePattern(aboutImg));
        Label aboutLb = new Label("", aboutCircle);
        //
        Image addImg = new Image("file:add.png");
        Circle addCircle = new Circle(200, 200, 60);
        addCircle.setFill(new ImagePattern(addImg));
        Label addLb = new Label("", addCircle);
        //
        Image soldImg = new Image("file:sold.jpg");
        Circle soldCircle = new Circle(200, 200, 60);
        soldCircle.setFill(new ImagePattern(soldImg));
        Label soldLb = new Label("", soldCircle);
        //
        Image kogaimg = new Image("file:koga.png");
        Circle kogaCircle = new Circle(200, 200, 60);
        kogaCircle.setFill(new ImagePattern(kogaimg));
        Label kogaLb = new Label("", kogaCircle);
        //

        Image registerImg = new Image("file:person.png");
        Circle registerCircle = new Circle(200, 200, 60);
        registerCircle.setFill(new ImagePattern(registerImg));
        Label registerLb = new Label("", registerCircle);
        line.getChildren().addAll(addLb, kogaLb, soldLb, registerLb, aboutLb);
        //************************enterded and exited back

        setEnteredAndExited(addLb);
        setEnteredAndExited(soldLb);
        setEnteredAndExited(aboutLb);
        setEnteredAndExited(kogaLb);
        setEnteredAndExited(registerLb);
        //***********************

        //**bashy set tooltip akan
        setTextOnEntered(addLb, "Add Thing");
        setTextOnEntered(soldLb, "Sold Thing");
        setTextOnEntered(aboutLb, "About");
        setTextOnEntered(kogaLb, "Koga");
        setTextOnEntered(registerLb, "Create new account");

        //
        Label usernameLb = new Label("Welcome " + username_str);
        usernameLb.setFont(Font.font("lucida calligraphy", 50));
        //actionakany home
        aboutLb.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                About obj = new About();
                window.close();
                obj.display();

            }
        });
        addLb.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                AddClass obj = new AddClass();
                window.close();
                obj.display();
            }
        });
        kogaLb.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                Koga obj = new Koga();
                window.close();
                obj.display();
            }
        });
        registerLb.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                Register obj = new Register();
                window.close();
                obj.display();
            }
        });
        soldLb.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                Sold obj = new Sold();
                window.close();
                obj.display();
            }
        });

        logoutItem.setOnAction((e) -> {
            Login obj = new Login();
            window.close();
            obj.display();
        });
        ExitItem.setOnAction((e) -> {
            System.exit(0);
        });
        //****************************bo away agar admin nabw natwanet accont drwst bkat
        if (rule_str.equals("Employee")) {
            registerLb.setDisable(true);
        }

        //***********************
        //*********
        general.getChildren().addAll(usernameLb, line);
        mainHbox.setTop(bar);
        mainHbox.setCenter(general);
        Scene scene = new Scene(mainHbox, 800, 700);

        window.setTitle("Home");
        window.setScene(scene);
        window.show();
    }

    public void setEnteredAndExited(Label c) {
        c.setOnMouseEntered(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                c.setStyle("-fx-background-color: -fx-outer-border,"
                        + " -fx-inner-border, -fx-body-color;\n"
                        + "    -fx-background-insets: 0, 1, 2;"
                        + "    -fx-background-radius: 20,20,20;"
                );

            }
        });
        c.setOnMouseExited(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                c.setStyle(null);

            }
        });
    }

    public void setTextOnEntered(Label l, String s) {
        l.setTooltip(new Tooltip(s));
        l.setCursor(Cursor.HAND);
    }
}
