package mobileshop;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class BuyMobile {

    public void display() {
        //************************************* panakan
        Stage window = new Stage();
        BorderPane mainHbox = new BorderPane();

        BorderPane leftPn = new BorderPane();
        leftPn.setPrefSize(200, 500);
        leftPn.setStyle("-fx-background-color: #00A8F3");

        VBox rightBox = new VBox();
        rightBox.setSpacing(25);
        rightBox.setPrefSize(170, 500);
        rightBox.setPadding(new Insets(0, 0, 0, 0));

        mainHbox.setLeft(leftPn);
        mainHbox.setCenter(rightBox);

        //***************************************  componentakan
        TextField nametxt = new TextField();
        nametxt.setMaxWidth(200);
        nametxt.setPromptText(" name of Person");

        TextField valuetxt = new TextField();
        valuetxt.setMaxWidth(200);
        valuetxt.setPromptText("Price");

        TextField nameOfMobileTxt = new TextField();
        nameOfMobileTxt.setMaxWidth(200);
        nameOfMobileTxt.setPromptText(" name of mobile");
        Button saveBtn = new Button("Print");
        saveBtn.setStyle("-fx-background-color: #00A8F3");
        saveBtn.setPrefWidth(100);

        ImageView addimg = new ImageView(new Image("file:buy.png"));
        addimg.setFitHeight(150);
        addimg.setFitWidth(150);
        leftPn.setCenter(addimg);


        rightBox.getChildren().addAll(nametxt, nameOfMobileTxt, valuetxt, saveBtn);
        rightBox.setAlignment(Pos.CENTER);

        //************************************** mouse entered and exited
        AddClass ob = new AddClass();
        ob.setStyleEnteredAndExited(saveBtn);

        //*************************************
        Scene scene = new Scene(mainHbox, 700, 500);

        window.setTitle("Mobile M3amala");
        window.setScene(scene);
        window.show();
    }
}
