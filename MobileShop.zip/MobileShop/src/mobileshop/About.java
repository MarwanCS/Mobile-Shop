package mobileshop;

import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class About {

    public void display() {
        
        Stage window = new Stage();
        BorderPane mainHbox = new BorderPane();
        Pane topPn = new Pane();   //bashy saraway about
        VBox boxData=new VBox();  //aw boxay ka rasmakaw labely aboutakay lasara nawakan
        
        boxData.setAlignment(Pos.CENTER);   // bo away har shtekman xsta sarn  vbxoaka bcheta center
        topPn.setStyle("-fx-background-color: #00A8F3");    //rangy shyny bashy saraway about
        topPn.setPrefSize(400, 40);
        
        ImageView logoImg = new ImageView(new Image("file:logo.png"));
        logoImg.setFitHeight(100);    //dyarykrdny barzy logoy aboutaka
        logoImg.setFitWidth(180);    //pany logoy aboutaka
        Label aboutLb = new Label("Created By :\nMarwan Qadr \nHalwest Kawa\nShad Shafi3");
        aboutLb.setFont(Font.font("lucida calligraphy", 15));      //goryny fonty text  about
        
        boxData.getChildren().addAll(logoImg,aboutLb); 
        
        ImageView backImg = new ImageView(new Image("file:back.png"));  //rasmy backynaw buttony back ka la hamw bashakanda haya
        backImg.setFitHeight(30);
        backImg.setFitWidth(30);
        Button backBtn = new Button("", backImg);
        backBtn.setStyle("-fx-background-color: #00A8F3");
        backBtn.setPrefSize(50, 10);
        topPn.getChildren().add(backBtn);
        //************************enterded and exited back
        
        AddClass ob=new AddClass();    //objecteka la classy  add class bo away cally methody  setStyleAndEnterdExeted bkam w aw buttonay bo danerm ka damawet  mouse entered w exited y bo bnerm ama codakanm bo kwrt dakatawa
        ob.setStyleEnteredAndExited(backBtn);    //methodaak
        
        //***********************
        
          //*Actionakan
        backBtn.setOnMouseClicked(new EventHandler<MouseEvent>() {   //action y buttony back la hamw classakanda haman shta
            @Override
            public void handle(MouseEvent event) {
                Home obj = new Home();
                window.close();
                obj.display();
            }
        });

        //****************************6
        mainHbox.setTop(topPn);  //basha shynaka daxama top y borderpanaka
        mainHbox.setCenter(boxData);   //bashy rasmy logo w text w shtakash daxama center y borderpanaka
        Scene scene = new Scene(mainHbox, 400, 400);
        window.setTitle("About");
        window.setScene(scene);
        window.show();
    }
}
