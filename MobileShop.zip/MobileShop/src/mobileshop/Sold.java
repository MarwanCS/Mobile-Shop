package mobileshop;

import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class Sold {

    public void display() {
        //************************************* panakan
        Stage window = new Stage();
        BorderPane mainHbox = new BorderPane();
        //  mainHbox.setSpacing(180);   //spacy newan pana shynakawa textfield w shtakan

        BorderPane leftPn = new BorderPane();
        leftPn.setPrefSize(200, 600);
        leftPn.setStyle("-fx-background-color: #00A8F3");

        VBox rightBox = new VBox();

        rightBox.setSpacing(20);
        rightBox.setPrefSize(700, 600);
        rightBox.setPadding(new Insets(30, 0, 0, 20));

        mainHbox.setCenter(rightBox);
        mainHbox.setLeft(leftPn);

        //***************************************  componentakan
        HBox riz = new HBox();
        riz.setSpacing(30);

        Label soldLb = new Label("Sold Part");
        soldLb.setFont(Font.font("System", 30));

        Separator sep = new Separator();
        sep.setPrefSize(100, 20);

        ComboBox typeMawadCombo = new ComboBox();
        typeMawadCombo.getItems().addAll("Mobile", "parchay computer", "exsystwarat");
        typeMawadCombo.setValue("type mawad");

        TextField searchTxt = new TextField();
        searchTxt.setPromptText("Search");

        Button searchBtn = new Button("Search");
        searchBtn.setStyle("-fx-background-color: #00A8F3");
        searchBtn.setPrefWidth(100);
        
        ImageView addimg = new ImageView(new Image("file:sold1.png"));
        addimg.setFitHeight(180);
        addimg.setFitWidth(180);

        ImageView backImg = new ImageView(new Image("file:back.png"));
        backImg.setFitHeight(30);
        backImg.setFitWidth(30);
        
        Button backBtn = new Button("", backImg);
        backBtn.setStyle("-fx-background-color: #00A8F3");
        backBtn.setPrefSize(50, 10);

        leftPn.setTop(backBtn);
        leftPn.setCenter(addimg);

        riz.getChildren().addAll(typeMawadCombo, searchTxt, searchBtn);

        rightBox.setAlignment(Pos.TOP_LEFT);

        //***** Table
        TableView table = new TableView();
        table.setPrefWidth(10);
        
        rightBox.getChildren().addAll(soldLb, sep, riz, table);

        //******
        //************************************** mouse entered and exited
        AddClass ob = new AddClass();
        ob.setStyleEnteredAndExited(backBtn);
        ob.setStyleEnteredAndExited(searchBtn);

        //*************************************
        //*Actionakan
        backBtn.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                Home obj = new Home();
                window.close();
                obj.display();
            }
        });

        //
        Scene scene = new Scene(mainHbox, 910, 600);

        window.setTitle("Sold");
        window.setScene(scene);
        window.show();
    }
}
