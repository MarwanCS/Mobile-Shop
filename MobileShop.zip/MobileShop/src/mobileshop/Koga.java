package mobileshop;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class Koga {

    static ObservableList<Mawad> mawadakanList = FXCollections.observableArrayList();

    TableView kogaTable = new TableView();

    public void display() {
        //************************************* panakan
        Stage window = new Stage();
        BorderPane mainHbox = new BorderPane();
        BorderPane leftPn = new BorderPane();
        leftPn.setPrefSize(200, 600);
        leftPn.setStyle("-fx-background-color: #00A8F3");

        VBox rightBox = new VBox();

        rightBox.setSpacing(20);
        rightBox.setPrefSize(700, 600);
        rightBox.setPadding(new Insets(30, 0, 0, 20));

        mainHbox.setLeft(leftPn);
        mainHbox.setCenter(rightBox);
        //***************************************  componentakan
        HBox riz = new HBox();  //aw hbox ay ka combo box w button w textfield w shtakany lasara
        riz.setSpacing(30);  //space newan combobo w stext w shtakan
        Label soldLb = new Label("Koga Part");   //texty sary saraway bashy koga
        soldLb.setFont(Font.font("System", 30));
        Separator sep = new Separator();   //xaty zher text koga part
        sep.setPrefSize(100, 1);  //pany xataka

        ComboBox typeMawadCombo = new ComboBox();
        typeMawadCombo.getItems().addAll("Mobile", "parchay computer", "exsystwarat");
        typeMawadCombo.setValue("type mawad"); //texty defaulty comboboxaka
        
        TextField searchTxt = new TextField();
        searchTxt.setPromptText("Search By Name");
        
        Button searchBtn = new Button("Search");
        searchBtn.setStyle("-fx-background-color: #00A8F3");
        searchBtn.setPrefWidth(100);
        
        Button buyBtn = new Button("Buy");
        buyBtn.setStyle("-fx-background-color: #00A8F3");
        
        ImageView backImg = new ImageView(new Image("file:back.png"));  //amagy buttonu back har la classy about bas krawa
        ImageView addimg = new ImageView(new Image("file:koga1.png"));   //rasmy naw pana shynaka
        
        addimg.setFitHeight(150);
        addimg.setFitWidth(150);
        backImg.setFitHeight(30);
        backImg.setFitWidth(30);
        
        leftPn.setCenter(addimg);   //bo away rasmy naw pana shynaka bcheta nawarastawa lay chap
        
        Button backBtn = new Button("", backImg);
        backBtn.setStyle("-fx-background-color: #00A8F3");
        backBtn.setPrefSize(50, 10);
        leftPn.setTop(backBtn);
        
        riz.getChildren().addAll(typeMawadCombo, searchTxt, searchBtn, buyBtn);
        
        rightBox.setAlignment(Pos.TOP_LEFT);  // bo away vboxaka shtakan lasarawa lay dasta chap dast bkat ba danany

        //buyBtn.setStyle("-fx-background-color: #00A8F3;-fx-text-fill:white;");
        buyBtn.setPrefWidth(100);

        //***** Table
        //  kogaTable.setMaxWidth(650);     //dyary krdny sizy tablaka
        rightBox.getChildren().addAll(soldLb, sep, riz, kogaTable);

        //******
        //************************************** mouse entered and exited
        AddClass ob = new AddClass();
        ob.setStyleEnteredAndExited(backBtn);
        ob.setStyleEnteredAndExited(searchBtn);
        ob.setStyleEnteredAndExited(buyBtn);
        //*************************************

        //*Actionakan
        backBtn.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                Home obj = new Home();
                window.close();
                obj.display();
            }
        });
        //actiony comboboxaka
        typeMawadCombo.setOnAction((e) -> {
            ObservableList<Mawad> listType = FXCollections.observableArrayList();
            for (int i = 0; i < mawadakanList.size(); i++) {
                System.out.println(mawadakanList.get(i).type);
                if (mawadakanList.get(i).type.equals(typeMawadCombo.getValue() + "")) {
                    listType.add(mawadakanList.get(i));
                }
            }
            kogaTable.setItems(listType);
        });
        ///actiony searchaka

        searchBtn.setOnAction((e) -> {
            ObservableList<Mawad> listType = FXCollections.observableArrayList();
            if (searchTxt.getText().equals("")) {
                kogaTable.setItems(mawadakanList);
            } else {
                for (int i = 0; i < mawadakanList.size(); i++) {
                    System.out.println(mawadakanList.get(i).type);
                    if (mawadakanList.get(i).name.equals(searchTxt.getText())) {
                        listType.add(mawadakanList.get(i));
                    }
                }
                kogaTable.setItems(listType);
            }
        });

    //    kogaTable.setMaxWidth(600);
        //cally methody nardn datakan bo table
        sendDataToTable();
        //
        Scene scene = new Scene(mainHbox, 910, 600);

        // buyBtn.getStylesheets().add("file:style1.css");
        // scene.getStylesheets().add("file:style1.css");
        window.setTitle("Sold");
        window.setScene(scene);
        window.show();
    }

    public void sendDataToTable() {

        kogaTable.setStyle("-fx-background-color: #00A8F3");
        kogaTable.setMaxWidth(650);
        TableColumn nameColumn = new TableColumn("Name of marwan qadr");
        nameColumn.setCellValueFactory(new PropertyValueFactory("name"));
        nameColumn.setPrefWidth(200);
        TableColumn typeColumn = new TableColumn("Type");
        typeColumn.setCellValueFactory(new PropertyValueFactory("type"));
        TableColumn numberOfThingColumn = new TableColumn("Number");
        numberOfThingColumn.setCellValueFactory(new PropertyValueFactory("numOfthing"));
        TableColumn priceColumn = new TableColumn("Price");
        priceColumn.setCellValueFactory(new PropertyValueFactory("price"));
        TableColumn dateColumn = new TableColumn("Date");
        dateColumn.setCellValueFactory(new PropertyValueFactory("date"));
        kogaTable.getColumns().addAll(nameColumn, typeColumn, numberOfThingColumn, priceColumn, dateColumn);
        kogaTable.setItems(mawadakanList);
    }

    public void addMawad(String name_str, String type_str, int numberOfThing, double price, String date_str) {

        mawadakanList.add(new Mawad(name_str, numberOfThing, type_str, price, date_str));
    }
}
